POLEPOLE CAFE スタッフアプリ（Firebase接続版・初期設定用）

含まれる機能
- 業務チェック、在庫管理、仕込み管理、マニュアル、共有ノート、記録
- 元Excelから作成した data.json を利用
- Firebase Authentication（メール/パスワード）
- Firestore の shared/main ドキュメントにスタッフ共通データを保存
- 業務チェック内容からLINE共有文を作成

Firebaseプロジェクト設定は firebase.js に反映済みです。

重要：まだ公開完了ではありません。
1. Firebase Consoleで Firestore Rules を認証済みユーザーのみ read/write 可に設定してください。
2. Firebase Hostingを有効化し、このフォルダ内のファイルを公開してください。
3. Hosting公開後、URLをスタッフに共有してください。

推奨Firestore Rules（Firestore Database > Rules に貼り付けて Publish）:
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /shared/{document} {
      allow read, write: if request.auth != null;
    }
  }
}

注意：現状はログインした全スタッフが同じ共有データを編集できます。スタッフ用アカウント作成後に利用してください。初回アカウントを作成できる人を管理者にしてください。Firestoreのテストモードのまま公開しないでください。
