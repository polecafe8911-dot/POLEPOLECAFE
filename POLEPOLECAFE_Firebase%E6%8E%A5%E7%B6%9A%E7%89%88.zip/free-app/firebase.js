// Firebase configuration for POLEPOLECAFE
const firebaseConfig = {
  apiKey: "AIzaSyC3xILzwEFVRfPhUGA8nbovtQrBPABZ90o",
  authDomain: "polepolecafe.firebaseapp.com",
  projectId: "polepolecafe",
  storageBucket: "polepolecafe.firebasestorage.app",
  messagingSenderId: "904738626681",
  appId: "1:904738626681:web:3353825a57c7bd194e88a8"
};
firebase.initializeApp(firebaseConfig);
window.poleAuth = firebase.auth();
window.poleDb = firebase.firestore();
